import { reducer } from './reducer'

export type RootState = ReturnType<typeof reducer>
